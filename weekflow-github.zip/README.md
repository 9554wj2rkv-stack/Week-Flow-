<p align="center">
  <img src="assets/wordmark.png" alt="WeekFlow" width="420">
</p>

<p align="center">A weekly life operating system — not a to-do list.</p>

---

WeekFlow is a single-file, local-first weekly planner built around one idea:
protect training and work, and stop repeated life admin (chores, shopping)
from taking mental space or repeated typing.

No account, no backend, no tracking. Everything lives in your browser's
`localStorage`, on your device.

## Sections

- **Today** — just today: work, training, tasks, a quick add, a note.
- **Week** — the full seven days at a glance, with work and training as
  protected anchors that visually dominate the day they fall on.
- **Month** — a quiet calendar view showing the current week and your
  recurring training rhythm across the month.
- **Shopping** — a permanent, reusable grocery list. Tap what you need
  before a trip, check items off while you shop, clear the trip when done —
  the master list never resets.
- **Notes** — a free-form note per day for anything that doesn't fit
  elsewhere.

## Chores

Recurring life admin (laundry, calls, vitamins, bills…) lives in a
reusable list, not locked to any day. Press **+ Add** on a day and either
type something new or pick from your list — nothing is ever scheduled
automatically.

## Running it

This is a static site — there's nothing to build or install.

- **Locally:** open `index.html` directly in a browser, or serve the
  folder with any static server (e.g. `npx serve .`).
- **On your phone:** open it in Safari and use *Share → Add to Home
  Screen* for an app-like icon and full-screen window.

## Deploying to GitHub Pages

1. Push this repo to GitHub.
2. In the repo, go to **Settings → Pages**.
3. Under *Build and deployment*, set **Source** to `Deploy from a branch`,
   pick your default branch and `/ (root)`, then save.
4. GitHub will publish it at `https://<username>.github.io/<repo>/`.

## File structure

```
index.html        the entire app — markup, styles, and logic
manifest.json      PWA metadata (name, icons, theme colour)
assets/            app icon, favicon, and wordmark
```

## Data & privacy

Everything — your tasks, chores, shopping list, and notes — is stored
only in your browser's local storage. There is no server, no sync, and
no account. Clearing your browser's site data for this page will erase
it, so export/back up manually if that matters to you (Settings has no
export yet — worth adding if you rely on this daily).

## Status

Personal tool, built iteratively. No issue tracker or contribution
process — this is tuned to one person's week, not a general product.
